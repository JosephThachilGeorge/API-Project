This is the code used in the video tutorial I made here: https://www.youtube.com/watch?v=sbYXa6HJJ5M
